#ifndef Miscellaneous_Data_h
#define Miscellaneous_Data_h

#include<iostream>
#include<sstream>
#include<vector>

// ------------------------------- Enums --------------------------------

// Cache Placement Policies in enum format
enum PLACEMENT_POLICY
{ FULLY_ASSOCIATED, SET_ASSOCIATED, DIRECT_MAPPED, EXIT, POLICY_ERROR };

// Stores all data in enum format
enum INPUT
{ CACHE_SIZE, BLOCK_SIZE, WAYS, CACHING_ALGORITHM, INPUT_ERROR};

// Caching algorithms in enum format
enum CACHING_ALGORITHM
{ LRU, LFU, FIFO, ALGORITHMIC_ERROR };

// ----------------------------- Structure ------------------------------

// Stores all cache data that works in parallel.
struct CacheData
{
    // ---------------------------- Typedef ----------------------------
    
    // data = cache data stored per each block
    typedef std::string data;
    
    // ------------------------ Binary datasets -------------------------
    
       data addresses,        // Stores each binary address
            tag,              // Stores each tag in binary form
            offset,           // Stores each offset in binary form
            index,            // Stores each index in binary form
            words,            // Stores each word in binary form
            instructions;     // Stores each instruction in binary form
    
};
// ---------------------------------------------------------------------

#endif
