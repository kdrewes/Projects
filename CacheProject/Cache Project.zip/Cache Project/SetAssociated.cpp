#include "SetAssociated.hpp"

SetAssociated :: ~SetAssociated() = default;

void SetAssociated :: Configure()
{
    
}

void SetAssociated::PrintFile()
{
    
}

void SetAssociated :: Print()
{
    std::cout << "\nPrint Set Associated Cache\n\n";
}

void SetAssociated :: LRU()
{
   
}

void SetAssociated :: FIFO()
{
  
}

void SetAssociated :: LFU()
{
  
}
