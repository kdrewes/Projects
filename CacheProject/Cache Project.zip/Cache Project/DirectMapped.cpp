#include "DirectMapped.hpp"

DirectMapped :: ~DirectMapped() = default;

void DirectMapped :: Configure()
{
    
}

void DirectMapped :: Print()
{
    std::cout << "\nPrint Console for Direct Mapped\n\n";
}
