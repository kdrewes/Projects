#ifndef Cache_hpp
#define Cache_hpp

#include <stdio.h>
#include <vector>
#include <fstream>
#include "Miscellaneous_Data.h"

// Interface for all cache placement policies
class Cache
{
    
protected:
    
    // -------------- Typedef used for organizational purposes -------------
    
    // unit = unit of measurements, input = variables uesd to select data, iterator = traverses through content
    typedef int unit, input, iterator;
    
    // inputSet = Stores input values
    typedef std::vector<std::string> inputSet;
    
    // Write file
    typedef std::ofstream file;
    
    // ---------------------------- File data ----------------------------
    
    file write;                // Establish file for Fully Associative,
                               // Set Associative & Direct Mapped Cache
    
    // -------------------------- Numerical data --------------------------
    
     unit cacheSize,          // Total amount of block data (Bytes)
          blockSize,          // Size of each block (Bytes)
          slots,              // slots = cacheSize / blockSize
          offsetSize,         // Offset size  (Bits)
          ways,               // Total amout of ways
          indexSize,          // Index size (Bits)
          wordSize;           // Word count = (block size / word size)
    
    // -------------------- Miscellaneous variables -------------------------
    
    enum CACHING_ALGORITHM algorithm;  // Select caching algorithm

public:
    
    // Default Constructor
    Cache();
    
    // Paramaterized Constructor
    Cache(PLACEMENT_POLICY policy);
    
    virtual ~Cache() = default;
    
    // -------------------- Features and Functionalities  ---------------------
    
    virtual void Print() = 0;             // Print report
    
    // --------------------------- Miscellaneous -----------------------------
    
    // Assigns variables to their correct placement policies
    void Assign(PLACEMENT_POLICY policy);
    
    // Assign Fully Associative variables
    void FullyAssociative();
    
    // Assign Set Associative variables
    void SetAssociative();
    
    // Assign Direct Mapped variables
    void DirectMapped();
    
    // Verfies user input for fully associative cache
    void verifyFullyAssociativeInput(std::pair<unit,iterator>verifyPair);
    
    // Verfies user input for set associative cache
    void verifySetAssociativeInput(std::pair<unit,iterator>verifyPair);
    
    // Verfies user input for direct map cache
    void verifyDirectMappedInput(std::pair<unit,iterator>verifyPair);
    
    // Determine input to select
    INPUT InputEnum(input number);
    
    // Determine caching algorithm to select
    enum CACHING_ALGORITHM CachingEnum(input number);
    
    // Menu for Fully Associated Cache
    std::string Fully_Associative_Menu(input select);
    
    // Menu for Set Associated Cache
    std::string Set_Associative_Menu(input select);
    
    // Menu for Direct Mapped Cache
    std::string Direct_Mapped_Menu(input select);
    
    // -------------------------------------------------------------------------
};

#endif
