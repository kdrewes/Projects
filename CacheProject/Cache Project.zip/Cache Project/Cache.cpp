#include "Cache.h"
#include "Miscellaneous_Data.h"

//----------------------------------------------------------------
Cache :: Cache(PLACEMENT_POLICY policy)
{
    Assign(policy);
}

//----------------------------------------------------------------

void Cache :: Assign(PLACEMENT_POLICY policy)
{
    switch(policy)
    {
        case FULLY_ASSOCIATED:
            
            FullyAssociative();
            
            break;
            
        case SET_ASSOCIATED:
            
            SetAssociative();
            
            break;
            
        case DIRECT_MAPPED:
            
            DirectMapped();
            
            break;
            
        case POLICY_ERROR:
            
            throw std::invalid_argument("\n------------------- Error --------------------\n\nIncorrect option\n\nPlease re-select from the following menu\n\n----------------------------------------------\n");
    }
}

//----------------------------------------------------------------

// Assign Fully Associative variables
void Cache :: FullyAssociative()
{
    
    // Input prompts used for Fully Associated Cache
   inputSet Fully_Associated_Input =
    {
        Fully_Associative_Menu(1),
        
        Fully_Associative_Menu(2),
        
        Fully_Associative_Menu(3),
        
        Fully_Associative_Menu(4)
    };
    
    // Select option
    input data;
    
    // Determines if banner should be displayed
    static bool isBanner = true;
    
    // Iterate through each input
    static iterator inputIterator = 0;
    
    // Fully Associative Cache Banner
    if(isBanner)
    {
        std::cout << "\n---------- Fully Associative Cache -----------\n";
        
        isBanner = false;
    }
    
    // Traverse through input values
    while(inputIterator < Fully_Associated_Input.size())
    {
        std::cout << Fully_Associated_Input[inputIterator];
        
        std::cin >> data;
        
        verifyFullyAssociativeInput({data,inputIterator});
        
        inputIterator += 1;
    }
    
    // Reset isBanner variable
    isBanner = false;
    
    // Reset inputIterator
    inputIterator = 0;
}

//----------------------------------------------------------------

void Cache :: SetAssociative()
{
    
    // Input prompts used for Set Associated Cache
   inputSet Set_Associated_Input =
    {
        Set_Associative_Menu(1),
        
        Set_Associative_Menu(2),
        
        Set_Associative_Menu(3),
        
        Set_Associative_Menu(4)
    };
    
    // Select option
    input data;
    
    // Determines if banner should be displayed
    static bool isBanner = true;
    
    // Iterate through each input
    static iterator inputIterator = 0;
    
    // Set Associative Cache Banner
    if(isBanner)
    {
        std::cout << "\n----------- Set Associative Cache ------------\n";
        
        isBanner = false;
    }
    
    // Traverse through input values
    while(inputIterator < Set_Associated_Input.size())
    {
        std::cout << Set_Associated_Input[inputIterator];
        
        std::cin >> data;
        
        verifySetAssociativeInput({data,inputIterator});
        
        inputIterator += 1;
    }
    
    // Reset isBanner variable
    isBanner = false;
    
    // Reset inputIterator
    inputIterator = 0;
}

//----------------------------------------------------------------

void Cache :: DirectMapped()
{
    // Input prompts used for Direct Mapped Cache
   inputSet Direct_Mapped_Input =
    {
        Direct_Mapped_Menu(1),
        
        Direct_Mapped_Menu(2)
    };
    
    // Select option
    input data;
    
    // Determines if banner should be displayed
    static bool isBanner = true;
    
    // Iterate through each input
    static iterator inputIterator = 0;
    
    // Direct Mapped Cache Banner
    if(isBanner)
    {
        std::cout << "\n----------- Direct Mapped Cache ------------\n";
        
        isBanner = false;
    }
    
    // Traverse through input values
    while(inputIterator < Direct_Mapped_Input.size())
    {
        std::cout << Direct_Mapped_Input[inputIterator];
        
        std::cin >> data;
        
        verifyDirectMappedInput({data,inputIterator});
        
        inputIterator += 1;
    }
    
    // Reset isBanner variable
    isBanner = false;
    
    // Reset inputIterator
    inputIterator = 0;
}

//----------------------------------------------------------------
// Verify fully associative cache input
void Cache :: verifyFullyAssociativeInput(std::pair<unit,iterator>verifyPair)
{
    unit data = verifyPair.first;
    
    iterator inputIterator = verifyPair.second;
    
    switch(InputEnum(inputIterator+ 1))
    {
            case CACHE_SIZE:
            
            if(data != 64 && data != 32)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nCache size must be 64 or 32 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> cacheSize = data;
            
            break;
            
            case BLOCK_SIZE:
            
            if(data != 8 && data != 4 && data != 2)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nBlock size must be 8, 4 or 2 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> blockSize = data;
            
            break;
            
            case WAYS:
            
            if(data != 2 && data != 3)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nAmount of ways must be 2 or 3\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> ways = data;
            
            break;
            
            case CACHING_ALGORITHM:
            
            if(data != 1 && data != 2 && data != 3)
               throw std::invalid_argument("\n--------------------- Error ----------------------\n\nIncorrect option\n\nPlease re-enter from the following menu:");
            
            this -> algorithm = CachingEnum(data);
            
            break;
            
            case INPUT_ERROR:
            
            throw std::invalid_argument("\n--------------------- Error ----------------------\n\nIncorrect input\n\nPlease re-enter a valid option\n\n--------------------------------------------------\n");
    }
}

//----------------------------------------------------------------
// Verify set associative cache input
void Cache :: verifySetAssociativeInput(std::pair<unit,iterator>verifyPair)
{
    unit data = verifyPair.first;
    
    iterator inputIterator = verifyPair.second;
    
    switch(InputEnum(inputIterator+ 1))
    {
            case CACHE_SIZE:
            
            if(data != 64 && data != 32)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nCache size must be 64 or 32 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> cacheSize = data;
            
            break;
            
            case BLOCK_SIZE:
            
            if(data != 8 && data != 4 && data != 2)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nBlock size must be 8, 4 or 2 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> blockSize = data;
            
            break;
            
            case WAYS:
            
            if(data != 2 && data != 3)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nAmount of ways must be 2 or 3\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> ways = data;
            
            break;
            
            case CACHING_ALGORITHM:
            
            if(data != 1 && data != 2 && data != 3)
               throw std::invalid_argument("\n--------------------- Error ----------------------\n\nIncorrect option\n\nPlease re-enter from the following menu:");
            
            this -> algorithm = CachingEnum(data);
            
            break;
            
            case INPUT_ERROR:
            
            throw std::invalid_argument("\n--------------------- Error ----------------------\n\nIncorrect input\n\nPlease re-enter a valid option\n\n--------------------------------------------------\n");
    }
}

//----------------------------------------------------------------
// Verify set associative cache input
void Cache :: verifyDirectMappedInput(std::pair<unit,iterator>verifyPair)
{
    unit data = verifyPair.first;
    
    iterator inputIterator = verifyPair.second;
    
    switch(InputEnum(inputIterator+ 1))
    {
            case CACHE_SIZE:
            
            if(data != 64 && data != 32)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nCache size must be 64 or 32 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> cacheSize = data;
            
            break;
            
            case BLOCK_SIZE:
            
            if(data != 8 && data != 4 && data != 2)
                throw std::invalid_argument("\n------------------- Error --------------------\n\nBlock size must be 8, 4 or 2 Bytes\n\nPlease re-enter value:\n\n----------------------------------------------\n");
            
            this -> blockSize = data;
            
            break;
            
            case INPUT_ERROR:
            
            throw std::invalid_argument("\n--------------------- Error ----------------------\n\nIncorrect input\n\nPlease re-enter a valid option\n\n--------------------------------------------------\n");
    }
}

//----------------------------------------------------------------
// Menu used for Fully Associated Cache
std::string Cache :: Fully_Associative_Menu(input select)
{
    if(select == 1)
        return "\n1) Cache Size (64 or 32 bytes): ";
    
    else if(select == 2)
        return "\n2) Block Size (8,4 or 2 bytes): ";
    
    else if(select == 3)
        return "\n3) Enter number of ways (2 or 3): ";
        
    else if(select == 4)
        return "\n--------------- Caching Algorithms ---------------\n\n1) Last Recently Used\t\t2) Last Frequently Used\n\n3) First In First Out\n\n--------------------------------------------------\n\nSelect: ";
    
    return "";
}

//----------------------------------------------------------------
// Menu used for Set Associative Cache
std::string Cache :: Set_Associative_Menu(input select)
{
    if(select == 1)
        return "\n1) Cache Size (64 or 32 bytes): ";
    
    else if(select == 2)
        return "\n2) Block Size (8,4 or 2 bytes): ";
    
    else if(select == 3)
        return "\n3) Enter number of ways (2 or 3): ";
        
    else if(select == 4)
        return "\n\n--------------- Caching Algorithms ---------------\n\n1) Last Recently Used\t\t2) Last Frequently Used\n\n3) First In First Out\n\n--------------------------------------------------\n\nSelect: ";
    
    return "";
}

//----------------------------------------------------------------
// Menu used for Direct Mapped Cache
std::string Cache :: Direct_Mapped_Menu(input select)
{
    if(select == 1)
        return "\n1) Cache Size (64 or 32 bytes): ";
    
    else if(select == 2)
        return "\n2) Block Size (8,4 or 2 bytes): ";
    
    return "";
}

//----------------------------------------------------------------
// Determine input to select
INPUT Cache :: InputEnum(input number)
{
    if(number == 1)
        return INPUT :: CACHE_SIZE;
    
    else if(number == 2)
        return INPUT :: BLOCK_SIZE;
    
    else if(number == 3)
        return INPUT :: WAYS;
    
    else if(number == 4)
        return INPUT :: CACHING_ALGORITHM;
    
    return INPUT :: INPUT_ERROR;
}

//----------------------------------------------------------------
// Determine caching algorithm to select
enum CACHING_ALGORITHM  Cache :: CachingEnum(input select)
{
    if(select == 1)
        return CACHING_ALGORITHM :: LRU;
    
    else if(select == 2)
        return CACHING_ALGORITHM :: LFU;
    
    else if(select == 3)
        return CACHING_ALGORITHM :: FIFO;
    
    return CACHING_ALGORITHM :: ALGORITHMIC_ERROR;
}

//----------------------------------------------------------------
