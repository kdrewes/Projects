#ifndef FullyAssociated_hpp
#define FullyAssociated_hpp

#include <stdio.h>
#include "Cache.h"
#include "Miscellaneous_Data.h"

class FullyAssociated : public Cache
{
    
    // ---------- Typedef for organizational purposes ----------
    
    // Unit of measurements
    typedef int units, input;
    
    
private:
    
    // -------------------------- Binary dataset ---------------------------
    
    // Store all data properties located in CacheData structure
    std::vector <CacheData> cacheVector;
    
public:
    
    FullyAssociated(PLACEMENT_POLICY policy) : Cache(policy)
    {
        Configure();
    }
    
    ~FullyAssociated() override;
    
    // ---------------------- Configuration functions  -----------------------
    
     void Configure();                  // Configure binary data
    
    // ------------------- Cache Replacements Algorithms  --------------------
    
     void LRU();                        // Last Recently Used
    
     void FIFO();                       // First in First Out
    
     void LFU();                        // Least Frequently Used
    
    // ---------------------------- Print Results  -----------------------------
    
     void Print() override;             // Print report
    
     void PrintFile();                  // Output results in file
    
     void PrintConsole();               // Output results in console
    
    
};

#endif 
