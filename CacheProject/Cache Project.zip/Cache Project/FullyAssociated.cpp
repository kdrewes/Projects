#include "FullyAssociated.hpp"

FullyAssociated :: ~FullyAssociated() = default;

void FullyAssociated :: Configure()
{
    // Calculate # of slots
    this -> slots = this -> cacheSize / this -> blockSize;
    
    // Generate binary data
}

void FullyAssociated :: Print()
{
    std::cout << "\nPrint Fully Associated Cache\n\n";
}

void FullyAssociated::PrintFile()
{
    
}


void FullyAssociated :: LRU()
{
   
}

void FullyAssociated :: FIFO()
{
  
}

void FullyAssociated :: LFU()
{
  
}
